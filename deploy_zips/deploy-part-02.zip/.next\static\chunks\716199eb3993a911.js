__turbopack_load_page_chunks__("/_app", [
  "static/chunks/98e9d61ee294e4ab.js",
  "static/chunks/c0df086a396e0baa.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/7c2ec2abfa3b773c.css",
  "static/chunks/turbopack-cc78fd7a1707aa9c.js"
])
