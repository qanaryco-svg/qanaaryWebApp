__turbopack_load_page_chunks__("/admin/gamification", [
  "static/chunks/2be1c8235a2ea23c.js",
  "static/chunks/ae3461839d4f9ca9.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/turbopack-ffed9fef538b4116.js"
])
