__turbopack_load_page_chunks__("/admin/login", [
  "static/chunks/eb1e4326b1d27c34.js",
  "static/chunks/610466d4ee2163e7.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/turbopack-443099b9ed1ba16b.js"
])
