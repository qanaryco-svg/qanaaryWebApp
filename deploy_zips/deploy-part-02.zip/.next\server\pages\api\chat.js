var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/chat.js")
R.c("server/chunks/[root-of-the-server]__3357c485._.js")
R.c("server/chunks/[root-of-the-server]__5b60bc93._.js")
R.m(98716)
module.exports=R.m(98716).exports
