var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__29cf46c2._.js")
R.c("server/chunks/ssr/_2f876c72._.js")
R.c("server/chunks/ssr/_ceeb5bd9._.js")
R.m(67298)
module.exports=R.m(67298).exports
