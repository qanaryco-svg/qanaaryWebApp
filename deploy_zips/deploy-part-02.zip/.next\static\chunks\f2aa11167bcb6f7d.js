__turbopack_load_page_chunks__("/admin", [
  "static/chunks/6a2d936fdfa9b61f.js",
  "static/chunks/ae3461839d4f9ca9.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/turbopack-8707ef229e4cf51c.js"
])
