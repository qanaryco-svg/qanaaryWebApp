__turbopack_load_page_chunks__("/cart", [
  "static/chunks/14abd984e472b289.js",
  "static/chunks/b6ea9b35f60dca1d.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/turbopack-86ef766c7f6f9392.js"
])
