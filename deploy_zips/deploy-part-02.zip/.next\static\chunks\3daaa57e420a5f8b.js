__turbopack_load_page_chunks__("/admin/branding", [
  "static/chunks/c262fb82bfcc5826.js",
  "static/chunks/475b95178ba34b30.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/turbopack-cf7ed1cb7e343a56.js"
])
