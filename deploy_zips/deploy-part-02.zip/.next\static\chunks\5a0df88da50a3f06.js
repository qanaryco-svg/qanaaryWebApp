__turbopack_load_page_chunks__("/test", [
  "static/chunks/65a1161c0b53fff7.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/turbopack-647d1d6246abad02.js"
])
