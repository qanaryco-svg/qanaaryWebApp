__turbopack_load_page_chunks__("/_error", [
  "static/chunks/73f150099cbb7b2f.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/turbopack-d06f9f7eda3929d6.js"
])
