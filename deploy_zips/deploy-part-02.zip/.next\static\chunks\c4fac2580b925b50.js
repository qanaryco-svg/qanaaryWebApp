__turbopack_load_page_chunks__("/style-finder", [
  "static/chunks/b6ea9b35f60dca1d.js",
  "static/chunks/36b8e896805d8a8d.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/turbopack-1f951e4cff17e302.js"
])
