globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/b6ea9b35f60dca1d.js",
      "static/chunks/5449e458c965ff9d.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-bf3b777d42549a30.js"
    ],
    "/_app": [
      "static/chunks/98e9d61ee294e4ab.js",
      "static/chunks/c0df086a396e0baa.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/7c2ec2abfa3b773c.css",
      "static/chunks/turbopack-cc78fd7a1707aa9c.js"
    ],
    "/_error": [
      "static/chunks/73f150099cbb7b2f.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/turbopack-d06f9f7eda3929d6.js"
    ],
    "/admin": [
      "static/chunks/6a2d936fdfa9b61f.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-8707ef229e4cf51c.js"
    ],
    "/admin/_app": [
      "static/chunks/6480e2d5cbe80443.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/turbopack-fdb665c9d0582345.js"
    ],
    "/admin/_debug_payments": [
      "static/chunks/3d8aa9cd4bdefaef.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-06f4e2411fc3dd64.js"
    ],
    "/admin/blog": [
      "static/chunks/ae8cb7d9362bc6c6.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-fab7fe3af9529e98.js"
    ],
    "/admin/branding": [
      "static/chunks/c262fb82bfcc5826.js",
      "static/chunks/475b95178ba34b30.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-cf7ed1cb7e343a56.js"
    ],
    "/admin/categories": [
      "static/chunks/f5c2da88863f31c9.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-35625ca713b30242.js"
    ],
    "/admin/cms": [
      "static/chunks/ee3a96543b60af8e.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-291d12bf99adf398.js"
    ],
    "/admin/comments": [
      "static/chunks/fbd857ce4c543c32.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-bef394f8a4cd867d.js"
    ],
    "/admin/content": [
      "static/chunks/e5f6686efc286f1e.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-7a8b4046704b0f8d.js"
    ],
    "/admin/footer": [
      "static/chunks/d97cdd0ea3a14a84.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-682cf1c218daadc6.js"
    ],
    "/admin/gamification": [
      "static/chunks/2be1c8235a2ea23c.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-ffed9fef538b4116.js"
    ],
    "/admin/header": [
      "static/chunks/f096229c156dd51c.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-183be23adce42003.js"
    ],
    "/admin/login": [
      "static/chunks/eb1e4326b1d27c34.js",
      "static/chunks/610466d4ee2163e7.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-443099b9ed1ba16b.js"
    ],
    "/admin/manage": [
      "static/chunks/70a50124f8bf36dc.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-fecfd27831f27396.js"
    ],
    "/admin/marketing": [
      "static/chunks/cc87d562bcebd2d8.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-4e937fa90423195f.js"
    ],
    "/admin/media": [
      "static/chunks/a3e2593936a389ed.js",
      "static/chunks/475b95178ba34b30.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-1ca94ab789ce4dc4.js"
    ],
    "/admin/orders": [
      "static/chunks/ca45f2860dd0d698.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-0bc8d388bf8a029d.js"
    ],
    "/admin/style-finder": [
      "static/chunks/ef465e6aecafe4b9.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-b6f3900508ce9aef.js"
    ],
    "/admin/users": [
      "static/chunks/682529f6e728d6d6.js",
      "static/chunks/ae3461839d4f9ca9.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-67e49dc3cc01604f.js"
    ],
    "/cart": [
      "static/chunks/14abd984e472b289.js",
      "static/chunks/b6ea9b35f60dca1d.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-86ef766c7f6f9392.js"
    ],
    "/checkout": [
      "static/chunks/b6ea9b35f60dca1d.js",
      "static/chunks/035b94bc34f84e6d.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-f978b70d392f9b26.js"
    ],
    "/membership": [
      "static/chunks/c4621830c44e9034.js",
      "static/chunks/b6ea9b35f60dca1d.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-1a25765410185850.js"
    ],
    "/membership/club": [
      "static/chunks/44dbca5515bcf049.js",
      "static/chunks/b6ea9b35f60dca1d.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-7b1e1a4730e1c229.js"
    ],
    "/membership/login": [
      "static/chunks/7375d71d2b36d5e9.js",
      "static/chunks/475b95178ba34b30.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-45f61a18101cdb5a.js"
    ],
    "/membership/register": [
      "static/chunks/a46d41f768d24842.js",
      "static/chunks/475b95178ba34b30.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-82b1c33c4d7fe6c9.js"
    ],
    "/products/[id]": [
      "static/chunks/475b95178ba34b30.js",
      "static/chunks/6b3d847e24ccd098.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-f81bd0bcc69a745a.js"
    ],
    "/style-finder": [
      "static/chunks/b6ea9b35f60dca1d.js",
      "static/chunks/36b8e896805d8a8d.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/turbopack-1f951e4cff17e302.js"
    ],
    "/test": [
      "static/chunks/65a1161c0b53fff7.js",
      "static/chunks/b4900be1709ebbaa.js",
      "static/chunks/0ec70ab358f696bb.js",
      "static/chunks/turbopack-647d1d6246abad02.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];