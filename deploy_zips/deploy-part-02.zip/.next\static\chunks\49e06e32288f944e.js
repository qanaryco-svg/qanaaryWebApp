__turbopack_load_page_chunks__("/", [
  "static/chunks/b6ea9b35f60dca1d.js",
  "static/chunks/5449e458c965ff9d.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/turbopack-bf3b777d42549a30.js"
])
