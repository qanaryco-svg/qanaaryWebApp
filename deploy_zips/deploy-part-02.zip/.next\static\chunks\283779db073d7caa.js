__turbopack_load_page_chunks__("/admin/media", [
  "static/chunks/a3e2593936a389ed.js",
  "static/chunks/475b95178ba34b30.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/turbopack-1ca94ab789ce4dc4.js"
])
