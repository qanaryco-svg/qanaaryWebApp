self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/49e06e32288f944e.js"
  ],
  "/_error": [
    "static/chunks/314c4d216488c158.js"
  ],
  "/admin": [
    "static/chunks/f2aa11167bcb6f7d.js"
  ],
  "/admin/_app": [
    "static/chunks/6a672c83ae028df0.js"
  ],
  "/admin/_debug_payments": [
    "static/chunks/e079c24e91651a5b.js"
  ],
  "/admin/blog": [
    "static/chunks/157160010b0a342b.js"
  ],
  "/admin/branding": [
    "static/chunks/3daaa57e420a5f8b.js"
  ],
  "/admin/categories": [
    "static/chunks/9012c651673e5549.js"
  ],
  "/admin/cms": [
    "static/chunks/aa7f409a4c75d295.js"
  ],
  "/admin/comments": [
    "static/chunks/d43cd9c34cd4ec2f.js"
  ],
  "/admin/content": [
    "static/chunks/ddbe20261454fb26.js"
  ],
  "/admin/footer": [
    "static/chunks/d28bc646b809426d.js"
  ],
  "/admin/gamification": [
    "static/chunks/7d8193fcea99c1d6.js"
  ],
  "/admin/header": [
    "static/chunks/5f897958d1c49463.js"
  ],
  "/admin/login": [
    "static/chunks/1e40956649840ff6.js"
  ],
  "/admin/manage": [
    "static/chunks/c35edd62fcade4df.js"
  ],
  "/admin/marketing": [
    "static/chunks/30b09e09ac1385d7.js"
  ],
  "/admin/media": [
    "static/chunks/283779db073d7caa.js"
  ],
  "/admin/orders": [
    "static/chunks/37911b286a75e244.js"
  ],
  "/admin/style-finder": [
    "static/chunks/5e88274615592844.js"
  ],
  "/admin/users": [
    "static/chunks/9e28c268a6157814.js"
  ],
  "/cart": [
    "static/chunks/7a247da9f2c8ac32.js"
  ],
  "/checkout": [
    "static/chunks/1873d1a44d5bc84d.js"
  ],
  "/membership": [
    "static/chunks/9a328cc05459e9ca.js"
  ],
  "/membership/club": [
    "static/chunks/d58677147c74109d.js"
  ],
  "/membership/login": [
    "static/chunks/60f777c5fa47fb7d.js"
  ],
  "/membership/register": [
    "static/chunks/c2d00443581585f6.js"
  ],
  "/products/[id]": [
    "static/chunks/4e5b1b63c0de84ef.js"
  ],
  "/style-finder": [
    "static/chunks/c4fac2580b925b50.js"
  ],
  "/test": [
    "static/chunks/5a0df88da50a3f06.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/admin",
    "/admin/_app",
    "/admin/_debug_payments",
    "/admin/blog",
    "/admin/branding",
    "/admin/categories",
    "/admin/cms",
    "/admin/comments",
    "/admin/content",
    "/admin/footer",
    "/admin/gamification",
    "/admin/header",
    "/admin/login",
    "/admin/manage",
    "/admin/marketing",
    "/admin/media",
    "/admin/orders",
    "/admin/style-finder",
    "/admin/users",
    "/api/chat",
    "/cart",
    "/checkout",
    "/membership",
    "/membership/club",
    "/membership/login",
    "/membership/register",
    "/products/[id]",
    "/style-finder",
    "/test"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()