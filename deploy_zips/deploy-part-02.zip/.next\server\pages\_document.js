var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__e81a3f3c._.js")
R.c("server/chunks/ssr/node_modules_next_76c6d695._.js")
R.m(39141)
module.exports=R.m(39141).exports
