__turbopack_load_page_chunks__("/admin/content", [
  "static/chunks/e5f6686efc286f1e.js",
  "static/chunks/ae3461839d4f9ca9.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/turbopack-7a8b4046704b0f8d.js"
])
