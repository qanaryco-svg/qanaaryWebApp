__turbopack_load_page_chunks__("/products/[id]", [
  "static/chunks/475b95178ba34b30.js",
  "static/chunks/6b3d847e24ccd098.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/turbopack-f81bd0bcc69a745a.js"
])
