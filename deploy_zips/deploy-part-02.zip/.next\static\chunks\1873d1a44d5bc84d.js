__turbopack_load_page_chunks__("/checkout", [
  "static/chunks/b6ea9b35f60dca1d.js",
  "static/chunks/035b94bc34f84e6d.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/turbopack-f978b70d392f9b26.js"
])
