__turbopack_load_page_chunks__("/admin/_app", [
  "static/chunks/6480e2d5cbe80443.js",
  "static/chunks/b4900be1709ebbaa.js",
  "static/chunks/0ec70ab358f696bb.js",
  "static/chunks/turbopack-fdb665c9d0582345.js"
])
